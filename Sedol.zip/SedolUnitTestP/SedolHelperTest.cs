﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sedol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sedoltestproject
{
    [TestClass]
    public class SedolHelperTest
    {
        [TestMethod]
        [DataRow(null)]
        [DataRow("")]
        [DataRow("123456789")]
        [DataRow("12")]
        public void ValidLengthChecks(string input)
        {
            SedolHelper sedol = new SedolHelper(input);
            Assert.IsFalse(sedol.IsValidLength);
        }
        
        [TestMethod]
        [DataRow("9123458")]
        [DataRow("9aBcDe1")]
        public void UserDefinedSedols(string input)
        {
            SedolHelper sedol = new SedolHelper(input);
            Assert.IsTrue(sedol.IsUserDefined);
        }
        
        [TestMethod]
        [DataRow("9123457")]
        [DataRow("9aBcDe6")]
        public void UserDefinedSedolsWithIncorrectChecksum(string input)
        {
            SedolHelper sedol = new SedolHelper(input);
            Assert.IsFalse(sedol.HasValidCheckDigit);
        }

        [TestMethod]
        [DataRow("1234567")]
        [DataRow("1234566")]
        public void SedolsWithIncorrectChecksum(string input)
        {
            SedolHelper sedol = new SedolHelper(input);
            Assert.IsFalse(sedol.HasValidCheckDigit);
        }

    }
}
