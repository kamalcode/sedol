﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SedolInterfaces;
using System;

namespace Sedol.Tests
{
    [TestClass]
    public class SedolValidatorTests
    {

        [TestMethod]
        [DataRow("test")]
        public void SedolsNotSevenCharacters(string sedol)
        {
            var actual = new SedolValidator().ValidateSedol(sedol);
            var expected = new SedolValidationResult(sedol, false, false, "Invalid length");
            AssertValidationResult(expected, actual);
        }


        [TestMethod]
        [DataRow("9123458")]
        public void UserDefinedSedolsWithCorrectChecksum(string sedol)
        {
            var actual = new SedolValidator().ValidateSedol(sedol);
            var expected = new SedolValidationResult(sedol, true, true, null);
            AssertValidationResult(expected, actual);
        }

        [TestMethod]
        [DataRow("9123457")]
        public void UserDefinedSedolsWithIncorrectChecksum(string sedol)
        {
            var actual = new SedolValidator().ValidateSedol(sedol);
            var expected = new SedolValidationResult(sedol, false, true, "Invalid check sum");
            AssertValidationResult(expected, actual);
        }

        [TestMethod]
        [DataRow("1234567")]
        public void SedolsWithIncorrectChecksum(string sedol)
        {
            var actual = new SedolValidator().ValidateSedol(sedol);
            var expected = new SedolValidationResult(sedol, false, false, "Invalid check sum");
            AssertValidationResult(expected, actual);
        }
        private static void AssertValidationResult(ISedolValidationResult expected, ISedolValidationResult actual)
        {
            Assert.AreEqual(expected.InputString, actual.InputString, "Input String Failed");
            Assert.AreEqual(expected.IsValidSedol, actual.IsValidSedol, "Is Valid Failed");
            Assert.AreEqual(expected.IsUserDefined, actual.IsUserDefined, "Is User Defined Failed");
            Assert.AreEqual(expected.ValidationDetails, actual.ValidationDetails, "Validation Details Failed");
        }

    }
}
