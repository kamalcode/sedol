﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace Sedol
{
   public class SedolHelper
    {
        private readonly string _inputvalue;
        private const int _sedolLength = 7;
        private readonly List<int> _weights;

        public SedolHelper(string input)
        {
            _weights = new List<int> { 1, 3, 1, 7, 3, 9,1 };
            _inputvalue = input;
        }
        public bool IsValidLength
        {
            get { return !String.IsNullOrEmpty(_inputvalue) && _inputvalue.Length == _sedolLength; }
        }

        public bool IsUserDefined
        {
            get { return _inputvalue[0] == 9; }
        }

        public bool HasValidCheckDigit
        {
            get { return _inputvalue[6] == CheckDigit; }
        }

        public char CheckDigit
        {
            get
            {
                var codes = _inputvalue.Take(7 - 1).Select(Code).ToList();
                var weightedSum = _weights.Zip(codes, (w, c) => w * c).Sum();
                return Convert.ToChar(((10 - (weightedSum % 10)) % 10).ToString(CultureInfo.InvariantCulture));
            }
        }

        public static int Code(char input)
        {
            if (Char.IsLetter(input))
                return Char.ToUpper(input) - 55;
            return input - 48;
        }


    }
}
