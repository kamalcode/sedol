﻿using SedolInterfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sedol
{
    public class SedolValidator : ISedolValidator
    {
        public ISedolValidationResult ValidateSedol(string input)
        {

            var sedolHelper = new SedolHelper(input);

            var result = new SedolValidationResult
            {
                InputString = input,
                IsUserDefined = false,
                IsValidSedol = false,
                ValidationDetails = null
            };

            if (!sedolHelper.IsValidLength)
            {
                result.ValidationDetails = "Invalid length";
                return result;
            }

            if (sedolHelper.IsUserDefined)
            {
                result.IsUserDefined = true;
                if (sedolHelper.HasValidCheckDigit)
                {
                    result.IsValidSedol = true;
                    return result;
                }
                result.ValidationDetails = "Invalid check sum";
                return result;
            }

            if (sedolHelper.HasValidCheckDigit)
                result.IsValidSedol = true;
            else
                result.ValidationDetails = "Invalid check sum";

            return result;
        }
    }
}
