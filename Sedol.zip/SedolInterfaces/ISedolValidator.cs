﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SedolInterfaces
{
  public  interface ISedolValidator
    {
        ISedolValidationResult ValidateSedol(string input);

    }
}
